
export class SummaryRow{

columnRowName: string;
totalOffshore: number;
totalOnsite: number;
totalAllocated: number;
unbilledOffshore: number;
unbilledOnsite: number;
doNOTBILL: number;
totalUnbilled: number;
billedOffshore: number;
billedOnsite: number;
totalBilled: number;

}
