import { Component, OnInit } from '@angular/core';

import { SummaryRow} from '../app/summary-row';
import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import { NgModule } from '@angular/core';
import { SummaryService } from './summary.service';


@Component({
  selector: 'app-emp-summary-dashboard',
  templateUrl: './emp-summary-dashboard.component.html',
  styleUrls: ['./emp-summary-dashboard.component.css']
})



export class EmpSummaryDashboardComponent implements OnInit {
displayedColumns: string[] = ['columnRowName','totalOffshore','totalOnsite','totalOffshore','totalAllocated','unbilledOffshore','unbilledOnsite','doNOTBILL','totalUnbilled','billedOffshore','billedOnsite', 'totalBilled' ];

  summaryTable: SummaryRow[];


    getSummary(): void {
    this.summaryService.getSummary()
    .subscribe(summaryTable => this.summaryTable = summaryTable);
  }
  
  constructor(private summaryService: SummaryService) { }

  ngOnInit() {
    this.getSummary();

  }

}