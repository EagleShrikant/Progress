import { Injectable } from '@angular/core';


import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { SummaryRow} from '../app/summary-row';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class SummaryService {
private summaryURL = 'http://10.10.71.243:9082/getSummaryData'; 

constructor(
    private http: HttpClient,
    ) { }
 
  /** GET heroes from the server */
  getSummary(): Observable<SummaryRow[]> {
    return this.http.get<SummaryRow[]>(this.summaryURL)
      .pipe(
        /**tap(heroes => this.log('fetched heroes')),*/
        catchError(this.handleError('getSummary', []))
      );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
 
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
 
      // TODO: better job of transforming error for user consumption
      /**this.log(`${operation} failed: ${error.message}`);*/
 
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

}